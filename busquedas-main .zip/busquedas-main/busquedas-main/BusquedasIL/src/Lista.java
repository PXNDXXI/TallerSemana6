import javax.swing.*;

public class Lista {

    private Nodo inicio;
    private int tamano;

    public Lista() {
        inicio = null;
        tamano = 0;
    }

    /**
     * Método para agregar un valor entero al final de la lista
     */
    public void agregar(int dato, JTextArea textArea) {
        Nodo nuevoNodo = new Nodo(dato);

        if (inicio == null) {
            inicio = nuevoNodo;
        } else {
            Nodo actual = inicio;

            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }

            actual.siguiente = nuevoNodo;
        }

        tamano++;
        actualizarTextArea(textArea);
    }

    /**
     * Método para eliminar un valor entero de la lista
     */
    public boolean eliminar(int dato, JTextArea textArea) {

        if (inicio == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía.");
            return false;
        }

        if (inicio.dato == dato) {
            inicio = inicio.siguiente;
            tamano--;
            actualizarTextArea(textArea);
            return true;
        }

        Nodo actual = inicio;

        while (actual.siguiente != null && actual.siguiente.dato != dato) {
            actual = actual.siguiente;
        }

        if (actual.siguiente != null) {
            actual.siguiente = actual.siguiente.siguiente;
            tamano--;
            actualizarTextArea(textArea);
            return true;
        }

        JOptionPane.showMessageDialog(null, "Elemento no encontrado en la lista.");
        return false;
    }

    /**
     * Método para realizar una búsqueda lineal
     */
    public int buscarLineal(int dato) {

        Nodo actual = inicio;
        int posicion = 0;

        while (actual != null) {

            if (actual.dato == dato) {
                return posicion;
            }

            actual = actual.siguiente;
            posicion++;
        }

        return -1;
    }

    /**
     * Método para realizar una búsqueda interpolada
     * La lista debe estar ordenada
     */
    public int buscarInterpolado(int dato, JTextArea textArea) {

        ordenarBurbuja(textArea);

        int[] array = convertirAArray();

        int inicio = 0;
        int fin = tamano - 1;

        while (inicio <= fin &&
                dato >= array[inicio] &&
                dato <= array[fin]) {

            // Evita división por cero
            if (array[fin] == array[inicio]) {

                if (array[inicio] == dato) {
                    return inicio;
                } else {
                    return -1;
                }
            }

            int pos = inicio +
                    ((dato - array[inicio]) * (fin - inicio)
                            / (array[fin] - array[inicio]));

            if (array[pos] == dato) {
                return pos;
            }

            if (array[pos] < dato) {
                inicio = pos + 1;
            } else {
                fin = pos - 1;
            }
        }

        return -1;
    }

    /**
     * Método para ordenar usando Burbuja
     */
    public void ordenarBurbuja(JTextArea textArea) {

        if (inicio == null || inicio.siguiente == null) {
            return;
        }

        boolean intercambio;

        do {

            intercambio = false;

            Nodo actual = inicio;
            Nodo siguiente = inicio.siguiente;

            while (siguiente != null) {

                if (actual.dato > siguiente.dato) {

                    int temp = actual.dato;
                    actual.dato = siguiente.dato;
                    siguiente.dato = temp;

                    intercambio = true;
                }

                actual = siguiente;
                siguiente = siguiente.siguiente;
            }

        } while (intercambio);

        actualizarTextArea(textArea);
    }

    /**
     * Convierte la lista enlazada a un arreglo
     */
    private int[] convertirAArray() {

        int[] array = new int[tamano];

        Nodo actual = inicio;
        int i = 0;

        while (actual != null) {
            array[i] = actual.dato;
            actual = actual.siguiente;
            i++;
        }

        return array;
    }

    /**
     * Muestra la lista en el JTextArea
     */
    public void mostrarLista(JTextArea textArea) {

        if (inicio == null) {
            textArea.setText("La lista está vacía.");
            return;
        }

        StringBuilder listaStr = new StringBuilder();

        Nodo actual = inicio;

        while (actual != null) {
            listaStr.append(actual.dato).append("\n");
            actual = actual.siguiente;
        }

        listaStr.append("\nTamaño de la lista: ").append(tamano);

        textArea.setText(listaStr.toString());
    }

    /**
     * Actualiza el JTextArea
     */
    private void actualizarTextArea(JTextArea textArea) {
        mostrarLista(textArea);
    }
}
