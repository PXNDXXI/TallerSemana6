import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BusquedaGUI {

    private JTextField inputField;
    private JButton agregarButton;
    private JButton eliminarButton;
    private JButton ordenarButton;
    private JButton buscarLinealButton;
    private JButton buscarInterpoladaButton;
    private JTextArea txtResultado;
    private JPanel pGeneral;
    private JButton mostrarButton;

    Lista lista = new Lista();

    public BusquedaGUI() {

        // BOTÓN AGREGAR
        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = inputField.getText();
                try {
                    int valor = Integer.parseInt(input);
                    lista.agregar(valor, txtResultado);
                    JOptionPane.showMessageDialog(null,
                            "Elemento agregado correctamente.");
                    inputField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Introduce un número entero válido.");
                }
            }
        });

        // BOTÓN ELIMINAR
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = inputField.getText();
                try {
                    int valor = Integer.parseInt(input);
                    boolean eliminado = lista.eliminar(valor, txtResultado);
                    if (eliminado) {
                        JOptionPane.showMessageDialog(null,
                                "Elemento eliminado correctamente.");
                    }
                    inputField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Introduce un número entero válido.");
                }
            }
        });

        // BOTÓN ORDENAR
        ordenarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lista.ordenarBurbuja(txtResultado);
                JOptionPane.showMessageDialog(null,
                        "Lista ordenada con el método Burbuja.");
            }
        });

        // BOTÓN BÚSQUEDA LINEAL
        buscarLinealButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = inputField.getText();
                try {
                    int valor = Integer.parseInt(input);
                    int posicion = lista.buscarLineal(valor);
                    if (posicion == -1) {
                        JOptionPane.showMessageDialog(null,
                                "Elemento no encontrado.");
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "Elemento encontrado en la posición: " + posicion);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Introduce un número entero válido.");
                }
            }
        });

        // BOTÓN BÚSQUEDA INTERPOLADA
        buscarInterpoladaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = inputField.getText();
                try {
                    int valor = Integer.parseInt(input);
                    int posicion = lista.buscarInterpolado(valor, txtResultado);
                    if (posicion == -1) {
                        JOptionPane.showMessageDialog(null,
                                "Elemento no encontrado.");

                    } else {
                        JOptionPane.showMessageDialog(null,
                                "Elemento encontrado en la posición: " + posicion);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Introduce un número entero válido.");
                }
            }
        });

        // BOTÓN MOSTRAR
        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lista.mostrarLista(txtResultado);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("BusquedaGUI");
        frame.setContentPane(new BusquedaGUI().pGeneral);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}