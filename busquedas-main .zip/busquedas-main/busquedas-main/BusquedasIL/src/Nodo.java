public class Nodo {

    public int dato;
    public Nodo siguiente;

    /**
     * Constructor del nodo
     */
    public Nodo(int dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}